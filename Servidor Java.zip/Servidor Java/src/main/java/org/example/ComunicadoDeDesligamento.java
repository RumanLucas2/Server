package org.example;

public class ComunicadoDeDesligamento extends Comunicado
{}
