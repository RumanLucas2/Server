package org.example;

import java.io.Serializable;

public class Comunicado implements Serializable, Cloneable
{}
