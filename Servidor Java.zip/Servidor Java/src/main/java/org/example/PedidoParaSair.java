package org.example;

public class PedidoParaSair extends Comunicado
{}
